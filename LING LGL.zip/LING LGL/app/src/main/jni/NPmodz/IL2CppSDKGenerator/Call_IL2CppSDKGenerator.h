#pragma once

#include "Includes.h"
#include "IL2Cpp.h"
#include "Vector2.h"
#include "Vector3.h"
#include "Rect.h"
#include "Quaternion.h"
#include "MonoString.h"
#include "KittyMemory.h"
#include "KittyUtils.h"
#include "MemoryBackup.h"
#include "MemoryPatch.h"
