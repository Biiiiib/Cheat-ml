#pragma once

#include "Esp_Player.hpp"

//Draw
void DrawESP(ImDrawList *draw, int screenWidth, int screenHeight) {
	Draw_ESP(draw, screenWidth, screenHeight);
}
